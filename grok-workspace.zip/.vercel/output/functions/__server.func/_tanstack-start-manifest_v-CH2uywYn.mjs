//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CH2uywYn.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-iBiftup6.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-iBiftup6.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DP3TOfPj.js"]
	}
} });
//#endregion
export { tsrStartManifest };
